package com.example.myapplication

import android.net.Uri
import java.net.URI
import java.net.URL

class Item1(var image:String?=null,
            var name:String?=null,
            var price:String?=null) {
}

