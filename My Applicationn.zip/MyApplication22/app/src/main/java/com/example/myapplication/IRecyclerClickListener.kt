package com.example.myapplication

import android.view.View

interface IRecyclerClickListener {
    fun onItemClickListener(view: View?, postion:Int) {}
    fun ss(){}
}