package com.example.myapplication

import android.net.Uri

class Item(
    var key: String? =null,
    var name:String?=null,
    var image:String?=null,
    var price:String?=null) {
}

