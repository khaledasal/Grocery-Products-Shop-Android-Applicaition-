package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import com.bumptech.glide.Glide
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.database.ktx.getValue
import com.google.firebase.ktx.Firebase


class Edit : AppCompatActivity() {
    private lateinit var database: DatabaseReference
    lateinit var imageView: ImageView
    lateinit var button: Button
    lateinit var button1 : Button
    lateinit var  Name : EditText
    lateinit var  Price : EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)
        button=findViewById(R.id.get)
        button1=findViewById(R.id.addd)
        imageView = findViewById(R.id.image)
        Name = findViewById(R.id.Pname)
        Price = findViewById(R.id.Pprice)
        database = Firebase.database.reference
button1.setOnClickListener(){
    var x = intent.getSerializableExtra("key").toString()
        database.child("Drink").child(("0"+x)).child("name").setValue(Name.text.toString())


}
        FirebaseDatabase.getInstance()
            .getReference("Drink")
            .addListenerForSingleValueEvent(object: ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if(snapshot.exists())
                    {
                        for(drinkSnapshot in snapshot.children)
                        {
                            val intent = intent
                            var x = intent.getSerializableExtra("key").toString()
                            if(drinkSnapshot.key == ("0"+x)){
                                Name.setText(drinkSnapshot.child("name").getValue().toString())
                                Price.setText(drinkSnapshot.child("price").getValue().toString())

                                val imageUrl = drinkSnapshot.child("image").toString()
                                val imageUri = imageUrl.toUri().buildUpon().scheme("https").build()
                                Glide.with(imageView.context).load(imageUri).into(imageView)

                            }
                        }

                    }
                }
                override fun onCancelled(error: DatabaseError) {
                }
            })


    }
}


